package fr.matchspardate

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.core.view.setPadding

class MainActivity : Activity() {

    private val blue     = Color.rgb(21, 101, 192)
    private val blueLight= Color.rgb(227, 235, 250)
    private val green    = Color.rgb(27, 136, 56)
    private val orange   = Color.rgb(230, 119, 0)
    private val red      = Color.rgb(198, 40, 40)
    private val grey     = Color.rgb(90, 90, 90)
    private val bgColor  = Color.rgb(245, 247, 250)

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "MatchsParDate"

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(bgColor)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        header("⚽ MATCHSPARDATE")
        subHeader("Analyse statistique — 8 facteurs")

        // ── Équipes ──────────────────────────────────────────
        sectionTitle("ÉQUIPES")
        val teamRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val homeInput = editText("Équipe domicile")
        val awayInput = editText("Équipe extérieur")
        teamRow.addView(homeInput, LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(0,0,8,0) })
        teamRow.addView(awayInput, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(teamRow)

        // ── Scores récents domicile ──────────────────────────
        sectionTitle("MATCHS RÉCENTS — DOMICILE (scores: 2-1, 0-0, 1-2…)")
        val homeScores = editTextMulti("Ex: 2-1, 3-0, 1-1, 0-2, 2-0")
        root.addView(homeScores)

        // ── Scores récents extérieur ─────────────────────────
        sectionTitle("MATCHS RÉCENTS — EXTÉRIEUR")
        val awayScores = editTextMulti("Ex: 1-1, 0-1, 2-3, 1-0, 0-0")
        root.addView(awayScores)

        // ── H2H ─────────────────────────────────────────────
        sectionTitle("CONFRONTATIONS DIRECTES (H2H)")
        val h2hInput = editTextMulti("Ex: 1-0, 2-2, 0-1, 1-1")
        root.addView(h2hInput)

        // ── Classement (optionnel) ───────────────────────────
        sectionTitle("CLASSEMENT (optionnel)")
        val rankRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val homeRank  = editTextNum("Pos dom.  (ex: 3)")
        val awayRank  = editTextNum("Pos ext.  (ex: 7)")
        val totalTeams= editTextNum("Nb équipes (ex: 20)")
        rankRow.addView(homeRank,  LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(0,0,6,0) })
        rankRow.addView(awayRank,  LinearLayout.LayoutParams(0, -2, 1f).also { it.setMargins(0,0,6,0) })
        rankRow.addView(totalTeams,LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(rankRow)

        // ── Bouton ───────────────────────────────────────────
        val btn = Button(this).apply {
            text = "ANALYSER"
            setBackgroundColor(blue)
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 28, 0, 28)
        }
        val btnLp = LinearLayout.LayoutParams(-1, -2)
        btnLp.setMargins(0, 24, 0, 8)
        root.addView(btn, btnLp)

        // ── Zone de résultat ─────────────────────────────────
        val resultContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(resultContainer)

        // ── Action ───────────────────────────────────────────
        btn.setOnClickListener {
            resultContainer.removeAllViews()

            val teamH = homeInput.text.toString().ifBlank { "Domicile" }
            val teamA = awayInput.text.toString().ifBlank { "Extérieur" }

            val homeMatchList = parseScoresAsMatches(homeScores.text.toString(), teamH, teamA, atHome = true)
            val awayMatchList = parseScoresAsMatches(awayScores.text.toString(), teamA, teamH, atHome = false)
            val h2hList       = parseH2H(h2hInput.text.toString(), teamH, teamA)

            if (homeMatchList.isEmpty() && awayMatchList.isEmpty()) {
                resultContainer.addView(errorCard("Saisis au moins quelques scores pour lancer l'analyse."))
                return@setOnClickListener
            }

            // Classement optionnel
            val hRankVal = homeRank.text.toString().toIntOrNull()
            val aRankVal = awayRank.text.toString().toIntOrNull()
            val total    = totalTeams.text.toString().toIntOrNull() ?: 20
            val hStanding = if (hRankVal != null) LeagueStanding(teamH, hRankVal, total, 0, 0, 0, 0) else null
            val aStanding = if (aRankVal != null) LeagueStanding(teamA, aRankVal, total, 0, 0, 0, 0) else null

            val pred = MatchAnalyzer.predict(
                homeTeam = teamH, awayTeam = teamA,
                homeAllMatches = homeMatchList,
                awayAllMatches = awayMatchList,
                h2h = h2hList,
                homeStanding = hStanding,
                awayStanding = aStanding
            )

            // ── Affichage résultats ──────────────────────────
            showPrediction(resultContainer, teamH, teamA, pred)
        }

        footer("v3.0 • Modèle Dixon-Coles • 8 facteurs")
    }

    // ════════════════════════════════════════════════════
    //  AFFICHAGE DES RÉSULTATS
    // ════════════════════════════════════════════════════

    private fun showPrediction(container: LinearLayout, teamH: String, teamA: String, p: Prediction) {

        // ── 1/N/2 ────────────────────────────────────────
        container.addView(sectionCard("RÉSULTAT 1 / N / 2") {
            addProbRow(it, "1  $teamH", p.homeWin, green)
            addProbRow(it, "N  Nul",    p.draw,    orange)
            addProbRow(it, "2  $teamA", p.awayWin, red)
            addConfidence(it, p.confidence)
        })

        // ── Buts attendus + top scores ────────────────────
        container.addView(sectionCard("BUTS ATTENDUS & SCORES") {
            addRow(it, "Buts attendus", "%.2f – %.2f".format(p.expectedHomeGoals, p.expectedAwayGoals))
            addRow(it, "Score probable", p.mostLikelyScore)
            p.topScores.forEachIndexed { i, s ->
                addRow(it, "Top ${i+1}", "${s.score}  (%.1f%%)".format(s.probability * 100))
            }
        })

        // ── Over / Under ─────────────────────────────────
        container.addView(sectionCard("OVER / UNDER") {
            addProbRow(it, "Over 1.5",  p.over15, green)
            addProbRow(it, "Over 2.5",  p.over25, orange)
            addProbRow(it, "Over 3.5",  p.over35, red)
        })

        // ── BTTS & double chance ──────────────────────────
        container.addView(sectionCard("BTTS & DOUBLE CHANCE") {
            addProbRow(it, "Les 2 équipes marquent", p.bttsYes, green)
            addProbRow(it, "1 ou Nul (1N)",          p.homeOrDraw, blue)
            addProbRow(it, "2 ou Nul (2N)",          p.awayOrDraw, blue)
        })

        // ── Forme domicile ────────────────────────────────
        val hs = p.homeStats
        container.addView(sectionCard("FORME — $teamH") {
            addRow(it, "Forme (5 derniers)", hs.formString.ifEmpty { "N/A" })
            addRow(it, "Pts forme",          "${hs.formPoints}/15")
            addRow(it, "Série victoires",    "${hs.currentWinStreak} consécutives")
            addRow(it, "Série sans défaite", "${hs.unbeatenStreak} matchs")
            addRow(it, "Buts moy./match",    "%.2f marqués  /  %.2f encaissés".format(hs.weightedAvgGoalsFor, hs.weightedAvgGoalsAgainst))
            addRow(it, "Dom : marqués/enc.", "%.2f / %.2f".format(hs.homeAvgScored, hs.homeAvgConceded))
            addRow(it, "Clean sheets",       "${hs.cleanSheets} (%.0f%%)".format(hs.cleanSheetPct))
            addRow(it, "Efficacité off.",    "%.2f".format(hs.attackingEfficiency))
            addRow(it, "Efficacité déf.",    "%.2f".format(hs.defensiveEfficiency))
        })

        // ── Forme extérieur ───────────────────────────────
        val as_ = p.awayStats
        container.addView(sectionCard("FORME — $teamA") {
            addRow(it, "Forme (5 derniers)", as_.formString.ifEmpty { "N/A" })
            addRow(it, "Pts forme",          "${as_.formPoints}/15")
            addRow(it, "Série victoires",    "${as_.currentWinStreak} consécutives")
            addRow(it, "Série sans défaite", "${as_.unbeatenStreak} matchs")
            addRow(it, "Buts moy./match",    "%.2f marqués  /  %.2f encaissés".format(as_.weightedAvgGoalsFor, as_.weightedAvgGoalsAgainst))
            addRow(it, "Ext : marqués/enc.", "%.2f / %.2f".format(as_.awayAvgScored, as_.awayAvgConceded))
            addRow(it, "Clean sheets",       "${as_.cleanSheets} (%.0f%%)".format(as_.cleanSheetPct))
            addRow(it, "Efficacité off.",    "%.2f".format(as_.attackingEfficiency))
            addRow(it, "Efficacité déf.",    "%.2f".format(as_.defensiveEfficiency))
        })

        // ── H2H ──────────────────────────────────────────
        val h2h = p.h2hStats
        if (h2h != null && h2h.totalMatches > 0) {
            container.addView(sectionCard("H2H — CONFRONTATIONS DIRECTES") {
                addRow(it, "Matchs joués",    "${h2h.totalMatches}")
                addRow(it, "Victoires $teamH","${h2h.winsTeamA} (%.0f%%)".format(h2h.teamAWinPct))
                addRow(it, "Nuls",            "${h2h.draws} (%.0f%%)".format(h2h.drawPct))
                addRow(it, "Victoires $teamA","${h2h.winsTeamB} (%.0f%%)".format(h2h.teamBWinPct))
                addRow(it, "Buts moy. H2H",  "%.2f – %.2f".format(h2h.avgGoalsTeamA, h2h.avgGoalsTeamB))
                addRow(it, "Dernier résultat",h2h.lastResult)
            })
        }
    }

    // ════════════════════════════════════════════════════
    //  PARSING DES SCORES SAISIS
    // ════════════════════════════════════════════════════

    /** Parse "2-1, 0-0, 1-2" en liste de MatchResult.
     *  atHome=true  → l'équipe principale joue à domicile dans ces scores
     *  atHome=false → l'équipe principale joue à l'extérieur */
    private fun parseScoresAsMatches(
        input: String, mainTeam: String, opponent: String, atHome: Boolean
    ): List<MatchResult> {
        val regex = Regex("""(\d+)\s*[-:]\s*(\d+)""")
        return input.split(",", "\n", ";").mapIndexedNotNull { i, s ->
            regex.find(s)?.let { m ->
                val g1 = m.groupValues[1].toInt()
                val g2 = m.groupValues[2].toInt()
                if (atHome)
                    MatchResult("2026-01-${"%02d".format((30 - i).coerceAtLeast(1))}", "", mainTeam, opponent, g1, g2)
                else
                    MatchResult("2026-01-${"%02d".format((30 - i).coerceAtLeast(1))}", "", opponent, mainTeam, g2, g1)
            }
        }
    }

    /** Parse les H2H : score du point de vue de teamH */
    private fun parseH2H(input: String, teamH: String, teamA: String): List<MatchResult> {
        val regex = Regex("""(\d+)\s*[-:]\s*(\d+)""")
        return input.split(",", "\n", ";").mapIndexedNotNull { i, s ->
            regex.find(s)?.let { m ->
                MatchResult("2025-06-${"%02d".format((28 - i).coerceAtLeast(1))}", "H2H", teamH, teamA,
                    m.groupValues[1].toInt(), m.groupValues[2].toInt())
            }
        }
    }

    // ════════════════════════════════════════════════════
    //  HELPERS UI
    // ════════════════════════════════════════════════════

    private fun header(s: String) {
        val tv = TextView(this).apply {
            text = s; textSize = 22f; setTextColor(blue)
            setTypeface(null, Typeface.BOLD); setPadding(0, 8, 0, 4)
        }
        root.addView(tv)
    }

    private fun subHeader(s: String) {
        val tv = TextView(this).apply {
            text = s; textSize = 13f; setTextColor(grey); setPadding(0, 0, 0, 16)
        }
        root.addView(tv)
    }

    private fun sectionTitle(s: String) {
        val tv = TextView(this).apply {
            text = s; textSize = 11f; setTextColor(grey)
            setTypeface(null, Typeface.BOLD)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 16, 0, 4); layoutParams = lp
        }
        root.addView(tv)
    }

    private fun editText(hint: String): EditText = EditText(this).apply {
        this.hint = hint; setSingleLine()
        setBackgroundColor(Color.WHITE); setPadding(16, 20, 16, 20)
    }

    private fun editTextMulti(hint: String): EditText = EditText(this).apply {
        this.hint = hint; setSingleLine(false); minLines = 2
        setBackgroundColor(Color.WHITE); setPadding(16, 16, 16, 16)
    }

    private fun editTextNum(hint: String): EditText = EditText(this).apply {
        this.hint = hint; setSingleLine()
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setBackgroundColor(Color.WHITE); setPadding(12, 20, 12, 20)
    }

    private fun sectionCard(title: String, populate: (LinearLayout) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(20, 16, 20, 16)
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 13f; setTextColor(blue)
            setTypeface(null, Typeface.BOLD); setPadding(0, 0, 0, 10)
        })
        populate(box)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 10, 0, 0)
        box.layoutParams = lp
        return box
    }

    private fun addRow(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(0, 5, 0, 5)
        }
        row.addView(TextView(this).apply {
            text = label; textSize = 13f; setTextColor(grey)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply {
            text = value; textSize = 13f; setTextColor(Color.BLACK)
            setTypeface(null, Typeface.BOLD); gravity = android.view.Gravity.END
        }, LinearLayout.LayoutParams(-2, -2))
        parent.addView(row)
    }

    private fun addProbRow(parent: LinearLayout, label: String, pct: Double, color: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, 6, 0, 6)
        }
        // Label + %
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(TextView(this).apply {
            text = label; textSize = 14f; setTextColor(Color.DKGRAY)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "%.1f%%".format(pct); textSize = 14f
            setTextColor(color); setTypeface(null, Typeface.BOLD)
        })
        row.addView(top)
        // Barre de progression
        val bar = LinearLayout(this).apply {
            setBackgroundColor(Color.rgb(220, 220, 220))
        }
        val fill = LinearLayout.LayoutParams((pct.coerceIn(0.0, 100.0) * 7).toInt(), 10)
        val filled = android.view.View(this).apply { setBackgroundColor(color); layoutParams = fill }
        bar.addView(filled)
        row.addView(bar, LinearLayout.LayoutParams(-1, 10).also { it.setMargins(0, 4, 0, 0) })
        parent.addView(row)
    }

    private fun addConfidence(parent: LinearLayout, conf: Int) {
        parent.addView(TextView(this).apply {
            text = "Confiance du modèle : $conf%"; textSize = 11f
            setTextColor(grey); setPadding(0, 10, 0, 0)
        })
    }

    private fun errorCard(msg: String): TextView = TextView(this).apply {
        text = msg; textSize = 14f; setTextColor(red)
        setBackgroundColor(Color.rgb(255, 235, 235)); setPadding(20, 20, 20, 20)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 10, 0, 0); layoutParams = lp
    }

    private fun footer(s: String) {
        val tv = TextView(this).apply {
            text = s; textSize = 11f; setTextColor(grey); setPadding(0, 24, 0, 16)
        }
        root.addView(tv)
    }
}
