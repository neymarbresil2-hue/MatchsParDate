package fr.matchspardate

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// ═══════════════════════════════════════════════════════════════
//  DONNÉES DE BASE
// ═══════════════════════════════════════════════════════════════

enum class Outcome { WIN, DRAW, LOSS }

data class MatchResult(
    val date: String,           // "YYYY-MM-DD"
    val competition: String = "",
    val homeTeam: String,
    val awayTeam: String,
    val homeGoals: Int,
    val awayGoals: Int
) {
    fun goalsFor(team: String)     = if (team == homeTeam) homeGoals else awayGoals
    fun goalsAgainst(team: String) = if (team == homeTeam) awayGoals else homeGoals
    fun outcome(team: String): Outcome = when {
        goalsFor(team) > goalsAgainst(team) -> Outcome.WIN
        goalsFor(team) == goalsAgainst(team) -> Outcome.DRAW
        else -> Outcome.LOSS
    }
    fun daysAgo(ref: String): Int = try {
        val ry = ref.substring(0,4).toInt(); val rm = ref.substring(5,7).toInt(); val rd = ref.substring(8,10).toInt()
        val dy = date.substring(0,4).toInt(); val dm = date.substring(5,7).toInt(); val dd = date.substring(8,10).toInt()
        (ry - dy) * 365 + (rm - dm) * 30 + (rd - dd)
    } catch (e: Exception) { 90 }
}

// ═══════════════════════════════════════════════════════════════
//  CLASSEMENT (FACTEUR 7 — LEAGUE POSITION)
// ═══════════════════════════════════════════════════════════════

/**
 * Entrée de classement pour une équipe.
 * Fournir la position réelle dans le championnat en cours.
 * Si non disponible, laisser null → le moteur utilisera un score neutre.
 */
data class LeagueStanding(
    val team: String,
    val position: Int,          // 1 = premier, plus grand = plus bas
    val totalTeams: Int,        // nombre total d'équipes dans la ligue
    val points: Int,
    val matchesPlayed: Int,
    val goalsFor: Int,
    val goalsAgainst: Int
) {
    /** Position normalisée [0,1] : 1.0 = premier, 0.0 = dernier */
    val normalizedRank: Double
        get() = if (totalTeams <= 1) 0.5
                else 1.0 - (position - 1).toDouble() / (totalTeams - 1).toDouble()

    /** Points par match */
    val pointsPerGame: Double
        get() = if (matchesPlayed == 0) 0.0 else points.toDouble() / matchesPlayed

    /** Différence de buts */
    val goalDifference: Int get() = goalsFor - goalsAgainst
}

// ═══════════════════════════════════════════════════════════════
//  STATISTIQUES D'ÉQUIPE (FACTEURS 1-6, 8)
// ═══════════════════════════════════════════════════════════════

data class TeamStats(
    // ── Facteur 1 : Forme récente ──────────────────────────────
    /** "VVNDV" sur les 5 derniers matchs (V=Victoire N=Nul D=Défaite) */
    val formString: String,
    /** Points sur les 5 derniers matchs / 15 → [0,1] */
    val formScore: Double,
    /** Points sur les 5 derniers matchs (max 15) */
    val formPoints: Int,

    // ── Facteur 2 : Perfs domicile / extérieur ─────────────────
    /** Moyenne de buts marqués à domicile */
    val homeAvgScored: Double,
    /** Moyenne de buts encaissés à domicile */
    val homeAvgConceded: Double,
    /** % victoires à domicile */
    val homeWinPct: Double,
    /** Moyenne de buts marqués à l'extérieur */
    val awayAvgScored: Double,
    /** Moyenne de buts encaissés à l'extérieur */
    val awayAvgConceded: Double,
    /** % victoires à l'extérieur */
    val awayWinPct: Double,

    // ── Facteur 3 : Buts marqués / encaissés ──────────────────
    val totalGoalsScored: Int,
    val totalGoalsConceded: Int,
    val goalDifference: Int,

    // ── Facteur 5 : Séries victoires / défaites ────────────────
    val currentWinStreak: Int,
    val currentDrawStreak: Int,
    val currentLossStreak: Int,
    val longestWinStreak: Int,
    val longestLossStreak: Int,
    /** Matchs sans défaite consécutifs (actuels) */
    val unbeatenStreak: Int,

    // ── Facteur 6 : Moyenne de buts par match ─────────────────
    /** Moyenne buts marqués (tous matchs, pondérée temporellement) */
    val weightedAvgGoalsFor: Double,
    /** Moyenne buts encaissés (tous matchs, pondérée temporellement) */
    val weightedAvgGoalsAgainst: Double,
    /** Moyenne buts par match (pour + contre) */
    val avgTotalGoals: Double,
    /** % matchs Over 2.5 */
    val over25Pct: Double,
    /** % matchs BTTS */
    val bttsPct: Double,

    // ── Facteur 8 : Efficacité offensive / défensive ───────────
    /**
     * Efficacité offensive = buts marqués / tirs cadrés.
     * Si tirs non disponibles : approximation via ratio buts/match vs moy. ligue.
     * Valeur > 1.0 = au-dessus de la moyenne.
     */
    val attackingEfficiency: Double,
    /**
     * Efficacité défensive = (1 - buts encaissés / matchs) / moy. ligue encaissés.
     * Valeur > 1.0 = défense plus solide que la moyenne.
     */
    val defensiveEfficiency: Double,
    /** Feuilles blanches (clean sheets) */
    val cleanSheets: Int,
    /** Matchs sans marquer */
    val failedToScore: Int,
    /** % clean sheets */
    val cleanSheetPct: Double,

    // ── Comptages globaux ──────────────────────────────────────
    val matches: Int,
    val wins: Int,
    val draws: Int,
    val losses: Int,
    val points: Int,
    val winPct: Double,
    val drawPct: Double,
    val lossPct: Double
)

// ═══════════════════════════════════════════════════════════════
//  H2H (FACTEUR 4)
// ═══════════════════════════════════════════════════════════════

data class H2HStats(
    val totalMatches: Int,
    /** Victoires de l'équipe A (homeTeam dans la prédiction) */
    val winsTeamA: Int,
    val draws: Int,
    val winsTeamB: Int,
    val avgGoalsTeamA: Double,
    val avgGoalsTeamB: Double,
    val avgTotalGoals: Double,
    val lastResult: String,         // "2-1", "0-0", etc.
    val teamAWinPct: Double,
    val teamBWinPct: Double,
    val drawPct: Double,
    /** Série en cours pour l'équipe A : +N = N victoires, -N = N défaites, 0 = nul */
    val currentStreakTeamA: Int
)

// ═══════════════════════════════════════════════════════════════
//  PRÉDICTION ENRICHIE
// ═══════════════════════════════════════════════════════════════

data class ScoreProb(val score: String, val probability: Double)

data class FactorBreakdown(
    val recentForm: Double,          // contribution % au λ final
    val venuePerformance: Double,
    val goalsScoredConceded: Double,
    val headToHead: Double,
    val streaks: Double,
    val avgGoals: Double,
    val leaguePosition: Double,
    val attackDefenseEfficiency: Double
)

data class Prediction(
    // ── Résultat 1/N/2 ────────────────────────────────────────
    val homeWin: Double,
    val draw: Double,
    val awayWin: Double,

    // ── Buts attendus ─────────────────────────────────────────
    val expectedHomeGoals: Double,
    val expectedAwayGoals: Double,

    // ── Scores probables ──────────────────────────────────────
    val topScores: List<ScoreProb>,
    val mostLikelyScore: String,

    // ── Marchés Over/Under ────────────────────────────────────
    val over15: Double,
    val under15: Double,
    val over25: Double,
    val under25: Double,
    val over35: Double,
    val under35: Double,

    // ── BTTS ──────────────────────────────────────────────────
    val bttsYes: Double,
    val bttsNo: Double,

    // ── Double chance ─────────────────────────────────────────
    val homeOrDraw: Double,
    val awayOrDraw: Double,
    val homeOrAway: Double,

    // ── Qualité du modèle ─────────────────────────────────────
    /** Confiance [0-100] selon la quantité de données */
    val confidence: Int,
    /** Contribution détaillée de chaque facteur */
    val factorBreakdown: FactorBreakdown,

    // ── Stats des deux équipes (pour affichage) ───────────────
    val homeStats: TeamStats,
    val awayStats: TeamStats,
    val h2hStats: H2HStats?
)

// ═══════════════════════════════════════════════════════════════
//  MOTEUR PRINCIPAL
// ═══════════════════════════════════════════════════════════════

object MatchAnalyzer {

    private const val LEAGUE_AVG_HOME    = 1.50
    private const val LEAGUE_AVG_AWAY    = 1.15
    private const val DECAY_HALF_LIFE    = 60.0   // jours
    private const val MAX_GOALS          = 10

    // ── Poids de chaque facteur sur le λ final ──────────────
    private const val W_FORM            = 0.20   // 1. Forme récente
    private const val W_VENUE           = 0.20   // 2. Dom/Ext
    private const val W_GOALS           = 0.15   // 3. Buts marqués/encaissés
    private const val W_H2H             = 0.12   // 4. H2H
    private const val W_STREAK          = 0.08   // 5. Séries
    private const val W_AVG_GOALS       = 0.10   // 6. Moyenne buts/match
    private const val W_RANK            = 0.10   // 7. Classement
    private const val W_EFFICIENCY      = 0.05   // 8. Efficacité off/def
    // Somme = 1.00

    // ════════════════════════════════════════════════════════
    //  CALCUL DES STATISTIQUES (FACTEURS 1–3, 5–6, 8)
    // ════════════════════════════════════════════════════════

    fun stats(
        team: String,
        allMatches: List<MatchResult>,          // tous matchs, plus récents en premier
        homeMatches: List<MatchResult> = allMatches.filter { it.homeTeam == team },
        awayMatches: List<MatchResult> = allMatches.filter { it.awayTeam == team },
        leagueAvgScored: Double = LEAGUE_AVG_HOME,
        leagueAvgConceded: Double = LEAGUE_AVG_AWAY,
        referenceDate: String = todayString()
    ): TeamStats {
        val n = allMatches.size
        if (n == 0) return emptyStats()

        // ── Facteur 1 : Forme récente ──────────────────────────
        val last5 = allMatches.take(5)
        val formChars = last5.map { when (it.outcome(team)) {
            Outcome.WIN -> 'V'; Outcome.DRAW -> 'N'; Outcome.LOSS -> 'D'
        }}
        val formPts   = last5.sumOf { when (it.outcome(team)) { Outcome.WIN -> 3; Outcome.DRAW -> 1; else -> 0 } }
        val formScore = if (last5.isEmpty()) 0.5 else formPts.toDouble() / (last5.size * 3)

        // ── Facteur 2 : Dom / Ext ──────────────────────────────
        fun avgFor(list: List<MatchResult>)  = if (list.isEmpty()) 0.0 else list.sumOf { it.goalsFor(team) }.toDouble() / list.size
        fun avgAgt(list: List<MatchResult>)  = if (list.isEmpty()) 0.0 else list.sumOf { it.goalsAgainst(team) }.toDouble() / list.size
        fun winPctOf(list: List<MatchResult>) = if (list.isEmpty()) 0.0 else 100.0 * list.count { it.outcome(team) == Outcome.WIN } / list.size

        // ── Facteur 3 : Buts totaux ─────────────────────────────
        val totalGF = allMatches.sumOf { it.goalsFor(team) }
        val totalGA = allMatches.sumOf { it.goalsAgainst(team) }

        // ── Pondération temporelle (pour λ) ────────────────────
        var wGF = 0.0; var wGA = 0.0; var wTotal = 0.0
        for (m in allMatches) {
            val w = decayWeight(m.daysAgo(referenceDate))
            wGF    += m.goalsFor(team)     * w
            wGA    += m.goalsAgainst(team) * w
            wTotal += w
        }
        val wAvgGF = if (wTotal > 0) wGF / wTotal else totalGF.toDouble() / n
        val wAvgGA = if (wTotal > 0) wGA / wTotal else totalGA.toDouble() / n

        // ── Facteur 5 : Séries ──────────────────────────────────
        fun currentStreak(outcome: Outcome): Int {
            var c = 0; for (m in allMatches) { if (m.outcome(team) != outcome) break; c++ }; return c
        }
        fun longestStreak(outcome: Outcome): Int {
            var best = 0; var cur = 0
            for (m in allMatches.reversed()) {
                if (m.outcome(team) == outcome) { cur++; if (cur > best) best = cur } else cur = 0
            }
            return best
        }
        var unbeaten = 0
        for (m in allMatches) { if (m.outcome(team) == Outcome.LOSS) break; unbeaten++ }

        // ── Facteur 6 : Moyenne buts / match ───────────────────
        val over25Count = allMatches.count { it.homeGoals + it.awayGoals >= 3 }
        val bttsCount   = allMatches.count { it.homeGoals > 0 && it.awayGoals > 0 }

        // ── Facteur 8 : Efficacité off/def ─────────────────────
        // Offensive : buts/match normalisé par moy. ligue
        val attackEff = if (leagueAvgScored > 0) (totalGF.toDouble() / n) / leagueAvgScored else 1.0
        // Défensive : inverse des buts encaissés/match normalisé → plus la valeur est haute, meilleure est la défense
        val defEff    = if (leagueAvgConceded > 0 && n > 0)
                            leagueAvgConceded / (totalGA.toDouble() / n + 0.01)
                        else 1.0

        val wins   = allMatches.count { it.outcome(team) == Outcome.WIN }
        val draws  = allMatches.count { it.outcome(team) == Outcome.DRAW }
        val losses = n - wins - draws
        val cleanS = allMatches.count { it.goalsAgainst(team) == 0 }
        val noScore = allMatches.count { it.goalsFor(team) == 0 }

        return TeamStats(
            // Forme
            formString = String(formChars.toCharArray()),
            formScore  = formScore,
            formPoints = formPts,
            // Dom/Ext
            homeAvgScored    = avgFor(homeMatches),
            homeAvgConceded  = avgAgt(homeMatches),
            homeWinPct       = winPctOf(homeMatches),
            awayAvgScored    = avgFor(awayMatches),
            awayAvgConceded  = avgAgt(awayMatches),
            awayWinPct       = winPctOf(awayMatches),
            // Buts
            totalGoalsScored   = totalGF,
            totalGoalsConceded = totalGA,
            goalDifference     = totalGF - totalGA,
            // Séries
            currentWinStreak  = currentStreak(Outcome.WIN),
            currentDrawStreak = currentStreak(Outcome.DRAW),
            currentLossStreak = currentStreak(Outcome.LOSS),
            longestWinStreak  = longestStreak(Outcome.WIN),
            longestLossStreak = longestStreak(Outcome.LOSS),
            unbeatenStreak    = unbeaten,
            // Moyennes buts
            weightedAvgGoalsFor      = wAvgGF,
            weightedAvgGoalsAgainst  = wAvgGA,
            avgTotalGoals            = (totalGF + totalGA).toDouble() / n,
            over25Pct                = if (n == 0) 0.0 else 100.0 * over25Count / n,
            bttsPct                  = if (n == 0) 0.0 else 100.0 * bttsCount / n,
            // Efficacité
            attackingEfficiency = attackEff.coerceIn(0.1, 5.0),
            defensiveEfficiency = defEff.coerceIn(0.1, 5.0),
            cleanSheets         = cleanS,
            failedToScore       = noScore,
            cleanSheetPct       = if (n == 0) 0.0 else 100.0 * cleanS / n,
            // Globaux
            matches = n, wins = wins, draws = draws, losses = losses,
            points  = 3 * wins + draws,
            winPct  = pct(wins, n), drawPct = pct(draws, n), lossPct = pct(losses, n)
        )
    }

    // ════════════════════════════════════════════════════════
    //  H2H (FACTEUR 4)
    // ════════════════════════════════════════════════════════

    fun h2hStats(teamA: String, teamB: String, h2h: List<MatchResult>): H2HStats {
        if (h2h.isEmpty()) return emptyH2H(teamA)
        val wA = h2h.count { it.outcome(teamA) == Outcome.WIN }
        val dr = h2h.count { it.outcome(teamA) == Outcome.DRAW }
        val wB = h2h.size - wA - dr

        // Série en cours pour teamA
        var streak = 0
        for (m in h2h) {
            when (m.outcome(teamA)) {
                Outcome.WIN  -> if (streak >= 0) streak++ else break
                Outcome.LOSS -> if (streak <= 0) streak-- else break
                Outcome.DRAW -> break
            }
        }

        return H2HStats(
            totalMatches   = h2h.size,
            winsTeamA      = wA, draws = dr, winsTeamB = wB,
            avgGoalsTeamA  = h2h.map { it.goalsFor(teamA).toDouble()  }.average(),
            avgGoalsTeamB  = h2h.map { it.goalsFor(teamB).toDouble()  }.average(),
            avgTotalGoals  = h2h.map { (it.homeGoals + it.awayGoals).toDouble() }.average(),
            lastResult     = h2h.first().let { "${it.goalsFor(teamA)}-${it.goalsFor(teamB)}" },
            teamAWinPct    = pct(wA, h2h.size),
            teamBWinPct    = pct(wB, h2h.size),
            drawPct        = pct(dr, h2h.size),
            currentStreakTeamA = streak
        )
    }

    // ════════════════════════════════════════════════════════
    //  PRÉDICTION (TOUS FACTEURS)
    // ════════════════════════════════════════════════════════

    /**
     * Prédit le match en intégrant les 8 facteurs.
     *
     * @param homeTeam          Nom exact de l'équipe domicile
     * @param awayTeam          Nom exact de l'équipe extérieur
     * @param homeAllMatches    Tous les matchs récents de l'équipe domicile (dom+ext), récents en premier
     * @param awayAllMatches    Tous les matchs récents de l'équipe extérieur (dom+ext), récents en premier
     * @param h2h               Confrontations directes (récents en premier)
     * @param homeStanding      Classement actuel de l'équipe domicile (optionnel)
     * @param awayStanding      Classement actuel de l'équipe extérieur (optionnel)
     * @param leagueAvgHome     Moyenne buts à domicile dans cette ligue
     * @param leagueAvgAway     Moyenne buts à l'extérieur dans cette ligue
     * @param referenceDate     Date du match prédit "YYYY-MM-DD"
     */
    fun predict(
        homeTeam: String,
        awayTeam: String,
        homeAllMatches: List<MatchResult>,
        awayAllMatches: List<MatchResult>,
        h2h: List<MatchResult>               = emptyList(),
        homeStanding: LeagueStanding?        = null,
        awayStanding: LeagueStanding?        = null,
        leagueAvgHome: Double                = LEAGUE_AVG_HOME,
        leagueAvgAway: Double                = LEAGUE_AVG_AWAY,
        referenceDate: String                = todayString()
    ): Prediction {

        val hHome = homeAllMatches.filter { it.homeTeam == homeTeam }
        val hAway = homeAllMatches.filter { it.awayTeam == homeTeam }
        val aHome = awayAllMatches.filter { it.homeTeam == awayTeam }
        val aAway = awayAllMatches.filter { it.awayTeam == awayTeam }

        val hStats = stats(homeTeam, homeAllMatches, hHome, hAway, leagueAvgHome, leagueAvgAway, referenceDate)
        val aStats = stats(awayTeam, awayAllMatches, aHome, aAway, leagueAvgHome, leagueAvgAway, referenceDate)
        val h2hSt  = if (h2h.isNotEmpty()) h2hStats(homeTeam, awayTeam, h2h) else null

        // ── Construction du λ par couches ──────────────────────

        // Base : forme récente (facteur 1) — pondérée temporellement
        var lambdaHome = hStats.weightedAvgGoalsFor
        var lambdaAway = aStats.weightedAvgGoalsFor

        // Facteur 2 : performances domicile/extérieur spécifiques
        val homeVenueScore = if (hHome.isNotEmpty()) hStats.homeAvgScored else lambdaHome
        val awayVenueScore = if (aAway.isNotEmpty()) aStats.awayAvgScored else lambdaAway
        lambdaHome = W_FORM * lambdaHome + W_VENUE * homeVenueScore +
                     (1 - W_FORM - W_VENUE) * lambdaHome
        lambdaAway = W_FORM * lambdaAway + W_VENUE * awayVenueScore +
                     (1 - W_FORM - W_VENUE) * lambdaAway

        // Facteur 3 & 6 : normalisation Dixon-Coles
        // λ = attackStr × defenseStr × leagueAvg × homeBonus
        val homeAttackStr  = (hStats.weightedAvgGoalsFor  / leagueAvgHome).coerceIn(0.1, 5.0)
        val awayAttackStr  = (aStats.weightedAvgGoalsFor  / leagueAvgAway).coerceIn(0.1, 5.0)
        val homeDefenseStr = (hStats.weightedAvgGoalsAgainst / leagueAvgAway).coerceIn(0.1, 5.0)
        val awayDefenseStr = (aStats.weightedAvgGoalsAgainst / leagueAvgHome).coerceIn(0.1, 5.0)
        val dcLambdaHome = homeAttackStr * awayDefenseStr * leagueAvgHome * 1.15
        val dcLambdaAway = awayAttackStr * homeDefenseStr * leagueAvgAway
        lambdaHome = W_GOALS * dcLambdaHome + (1 - W_GOALS) * lambdaHome
        lambdaAway = W_GOALS * dcLambdaAway + (1 - W_GOALS) * lambdaAway

        // Facteur 4 : H2H
        if (h2hSt != null && h2hSt.totalMatches > 0) {
            val h2hW = min(0.25, h2hSt.totalMatches * 0.05)
            lambdaHome = (1 - h2hW) * lambdaHome + h2hW * h2hSt.avgGoalsTeamA
            lambdaAway = (1 - h2hW) * lambdaAway + h2hW * h2hSt.avgGoalsTeamB
        }

        // Facteur 5 : séries (boost/malus de ±8%)
        val homeStreakAdj = streakAdjustment(hStats.currentWinStreak, hStats.currentLossStreak)
        val awayStreakAdj = streakAdjustment(aStats.currentWinStreak, aStats.currentLossStreak)
        lambdaHome *= (1.0 + W_STREAK * homeStreakAdj)
        lambdaAway *= (1.0 + W_STREAK * awayStreakAdj)

        // Facteur 6 : ajustement forme récente ±10%
        val homeFormAdj = (hStats.formScore - 0.5) * 2.0  // [-1, +1]
        val awayFormAdj = (aStats.formScore - 0.5) * 2.0
        lambdaHome *= (1.0 + W_AVG_GOALS * homeFormAdj).coerceIn(0.88, 1.12)
        lambdaAway *= (1.0 + W_AVG_GOALS * awayFormAdj).coerceIn(0.88, 1.12)

        // Facteur 7 : classement
        val homeRankAdj = rankAdjustment(homeStanding)
        val awayRankAdj = rankAdjustment(awayStanding)
        lambdaHome *= (1.0 + W_RANK * homeRankAdj)
        lambdaAway *= (1.0 + W_RANK * awayRankAdj)

        // Facteur 8 : efficacité offensive/défensive
        lambdaHome *= (1.0 + W_EFFICIENCY * (hStats.attackingEfficiency - 1.0)).coerceIn(0.90, 1.10)
        lambdaAway *= (1.0 + W_EFFICIENCY * (aStats.attackingEfficiency - 1.0)).coerceIn(0.90, 1.10)
        // Pénalise si la défense adverse est très forte
        lambdaHome *= (1.0 - W_EFFICIENCY * (aStats.defensiveEfficiency - 1.0) * 0.5).coerceIn(0.90, 1.10)
        lambdaAway *= (1.0 - W_EFFICIENCY * (hStats.defensiveEfficiency - 1.0) * 0.5).coerceIn(0.90, 1.10)

        // Fallback si aucune donnée
        if (homeAllMatches.isEmpty()) lambdaHome = leagueAvgHome * 1.15
        if (awayAllMatches.isEmpty()) lambdaAway = leagueAvgAway
        lambdaHome = max(0.10, lambdaHome)
        lambdaAway = max(0.10, lambdaAway)

        // ── Matrice de scores Dixon-Coles ──────────────────────
        val rho = dixonColesRho(lambdaHome, lambdaAway)
        val matrix = Array(MAX_GOALS + 1) { hg ->
            DoubleArray(MAX_GOALS + 1) { ag ->
                exp(poissonLog(hg, lambdaHome) + poissonLog(ag, lambdaAway)) *
                dixonColesTau(hg, ag, lambdaHome, lambdaAway, rho)
            }
        }

        // ── Agrégation ─────────────────────────────────────────
        var pH = 0.0; var pD = 0.0; var pA = 0.0
        var o15 = 0.0; var o25 = 0.0; var o35 = 0.0; var btts = 0.0
        val scoreProbs = mutableListOf<ScoreProb>()
        for (hg in 0..MAX_GOALS) for (ag in 0..MAX_GOALS) {
            val p = matrix[hg][ag]
            when { hg > ag -> pH += p; hg == ag -> pD += p; else -> pA += p }
            val tot = hg + ag
            if (tot >= 2) o15 += p; if (tot >= 3) o25 += p; if (tot >= 4) o35 += p
            if (hg > 0 && ag > 0) btts += p
            scoreProbs += ScoreProb("$hg-$ag", p)
        }
        val totP = pH + pD + pA
        val top5 = scoreProbs.sortedByDescending { it.probability }.take(5)

        // ── Score de confiance ─────────────────────────────────
        val dataPts = homeAllMatches.size + awayAllMatches.size + h2h.size +
                      (if (homeStanding != null) 5 else 0) +
                      (if (awayStanding != null) 5 else 0)
        val confidence = min(95, when {
            dataPts >= 60 -> 88
            dataPts >= 40 -> 75
            dataPts >= 20 -> 60
            dataPts >= 10 -> 45
            else          -> 28
        })

        // ── Détail contributions ───────────────────────────────
        val breakdown = FactorBreakdown(
            recentForm               = W_FORM            * 100,
            venuePerformance         = W_VENUE           * 100,
            goalsScoredConceded      = W_GOALS           * 100,
            headToHead               = if (h2hSt != null) W_H2H * 100 else 0.0,
            streaks                  = W_STREAK          * 100,
            avgGoals                 = W_AVG_GOALS       * 100,
            leaguePosition           = if (homeStanding != null || awayStanding != null) W_RANK * 100 else 0.0,
            attackDefenseEfficiency  = W_EFFICIENCY      * 100
        )

        return Prediction(
            homeWin = 100 * pH / totP, draw = 100 * pD / totP, awayWin = 100 * pA / totP,
            expectedHomeGoals = lambdaHome, expectedAwayGoals = lambdaAway,
            topScores = top5, mostLikelyScore = top5.firstOrNull()?.score ?: "1-1",
            over15 = 100 * o15, under15 = 100 * (1 - o15),
            over25 = 100 * o25, under25 = 100 * (1 - o25),
            over35 = 100 * o35, under35 = 100 * (1 - o35),
            bttsYes = 100 * btts, bttsNo = 100 * (1 - btts),
            homeOrDraw = 100 * (pH + pD) / totP,
            awayOrDraw = 100 * (pA + pD) / totP,
            homeOrAway = 100 * (pH + pA) / totP,
            confidence     = confidence,
            factorBreakdown = breakdown,
            homeStats = hStats,
            awayStats = aStats,
            h2hStats  = h2hSt
        )
    }

    // ═══════════════════════════════════════════════════════
    //  MÉTHODES INTERNES
    // ═══════════════════════════════════════════════════════

    /** Ajustement série : +1 si 3+ victoires consécutives, -1 si 3+ défaites */
    private fun streakAdjustment(winStreak: Int, lossStreak: Int): Double = when {
        winStreak  >= 5 ->  1.0
        winStreak  >= 3 ->  0.5
        lossStreak >= 5 -> -1.0
        lossStreak >= 3 -> -0.5
        else            ->  0.0
    }

    /** Ajustement classement : [+1, -1] selon position normalisée */
    private fun rankAdjustment(standing: LeagueStanding?): Double {
        if (standing == null) return 0.0
        // normalizedRank : 1.0 = 1er, 0.0 = dernier → centrer autour de 0
        return (standing.normalizedRank - 0.5) * 2.0  // [-1, +1]
    }

    private fun dixonColesRho(lH: Double, lA: Double) =
        -0.13 * exp(-0.05 * (lH + lA - 2.65))

    private fun dixonColesTau(hg: Int, ag: Int, lH: Double, lA: Double, rho: Double) =
        when {
            hg == 0 && ag == 0 -> 1.0 - lH * lA * rho
            hg == 1 && ag == 0 -> 1.0 + lA * rho
            hg == 0 && ag == 1 -> 1.0 + lH * rho
            hg == 1 && ag == 1 -> 1.0 - rho
            else               -> 1.0
        }

    private fun poissonLog(k: Int, lambda: Double): Double {
        if (lambda <= 0.0) return if (k == 0) 0.0 else Double.NEGATIVE_INFINITY
        var lf = 0.0; for (i in 2..k) lf += ln(i.toDouble())
        return -lambda + k * ln(lambda) - lf
    }

    private fun decayWeight(days: Int) = exp(-ln(2.0) * days / DECAY_HALF_LIFE)

    private fun pct(v: Int, n: Int) = if (n == 0) 0.0 else 100.0 * v / n

    private fun todayString(): String {
        val c = java.util.Calendar.getInstance()
        return "%04d-%02d-%02d".format(
            c.get(java.util.Calendar.YEAR),
            c.get(java.util.Calendar.MONTH) + 1,
            c.get(java.util.Calendar.DAY_OF_MONTH)
        )
    }

    private fun emptyStats() = TeamStats(
        formString="", formScore=0.5, formPoints=0,
        homeAvgScored=0.0, homeAvgConceded=0.0, homeWinPct=0.0,
        awayAvgScored=0.0, awayAvgConceded=0.0, awayWinPct=0.0,
        totalGoalsScored=0, totalGoalsConceded=0, goalDifference=0,
        currentWinStreak=0, currentDrawStreak=0, currentLossStreak=0,
        longestWinStreak=0, longestLossStreak=0, unbeatenStreak=0,
        weightedAvgGoalsFor=0.0, weightedAvgGoalsAgainst=0.0,
        avgTotalGoals=0.0, over25Pct=0.0, bttsPct=0.0,
        attackingEfficiency=1.0, defensiveEfficiency=1.0,
        cleanSheets=0, failedToScore=0, cleanSheetPct=0.0,
        matches=0, wins=0, draws=0, losses=0, points=0,
        winPct=0.0, drawPct=0.0, lossPct=0.0
    )

    private fun emptyH2H(teamA: String) = H2HStats(
        totalMatches=0, winsTeamA=0, draws=0, winsTeamB=0,
        avgGoalsTeamA=0.0, avgGoalsTeamB=0.0, avgTotalGoals=0.0,
        lastResult="N/A", teamAWinPct=0.0, teamBWinPct=0.0, drawPct=0.0,
        currentStreakTeamA=0
    )
}
